﻿namespace LINQ
{
    partial class frmEmployeeGrid
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgvEmployees = new System.Windows.Forms.DataGridView();
            this.btnOrderByName = new System.Windows.Forms.Button();
            this.nameCandJ = new System.Windows.Forms.Button();
            this.surnameIorE = new System.Windows.Forms.Button();
            this.age20to23 = new System.Windows.Forms.Button();
            this.sameLetters = new System.Windows.Forms.Button();
            this.nameSurnameLenght = new System.Windows.Forms.Button();
            this.ageCourse = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployees)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvEmployees
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEmployees.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvEmployees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvEmployees.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgvEmployees.Location = new System.Drawing.Point(340, 13);
            this.dgvEmployees.Name = "dgvEmployees";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEmployees.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvEmployees.Size = new System.Drawing.Size(786, 384);
            this.dgvEmployees.TabIndex = 0;
            // 
            // btnOrderByName
            // 
            this.btnOrderByName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrderByName.Location = new System.Drawing.Point(13, 13);
            this.btnOrderByName.Name = "btnOrderByName";
            this.btnOrderByName.Size = new System.Drawing.Size(139, 30);
            this.btnOrderByName.TabIndex = 1;
            this.btnOrderByName.Text = "Order By Name";
            this.btnOrderByName.UseVisualStyleBackColor = true;
            this.btnOrderByName.Click += new System.EventHandler(this.btnOrderByName_Click);
            // 
            // nameCandJ
            // 
            this.nameCandJ.Location = new System.Drawing.Point(13, 49);
            this.nameCandJ.Name = "nameCandJ";
            this.nameCandJ.Size = new System.Drawing.Size(139, 38);
            this.nameCandJ.TabIndex = 2;
            this.nameCandJ.Text = "Name C and J";
            this.nameCandJ.UseVisualStyleBackColor = true;
            this.nameCandJ.Click += new System.EventHandler(this.nameCandJ_Click);
            // 
            // surnameIorE
            // 
            this.surnameIorE.Location = new System.Drawing.Point(13, 93);
            this.surnameIorE.Name = "surnameIorE";
            this.surnameIorE.Size = new System.Drawing.Size(139, 35);
            this.surnameIorE.TabIndex = 3;
            this.surnameIorE.Text = "Surname I or E";
            this.surnameIorE.UseVisualStyleBackColor = true;
            this.surnameIorE.Click += new System.EventHandler(this.surnameIorE_Click);
            // 
            // age20to23
            // 
            this.age20to23.Location = new System.Drawing.Point(13, 134);
            this.age20to23.Name = "age20to23";
            this.age20to23.Size = new System.Drawing.Size(139, 36);
            this.age20to23.TabIndex = 4;
            this.age20to23.Text = "Age 20-23";
            this.age20to23.UseVisualStyleBackColor = true;
            this.age20to23.Click += new System.EventHandler(this.age20to23_Click);
            // 
            // sameLetters
            // 
            this.sameLetters.Location = new System.Drawing.Point(13, 176);
            this.sameLetters.Name = "sameLetters";
            this.sameLetters.Size = new System.Drawing.Size(139, 35);
            this.sameLetters.TabIndex = 5;
            this.sameLetters.Text = "Same Letters";
            this.sameLetters.UseVisualStyleBackColor = true;
            this.sameLetters.Click += new System.EventHandler(this.sameLetters_Click);
            // 
            // nameSurnameLenght
            // 
            this.nameSurnameLenght.Location = new System.Drawing.Point(13, 217);
            this.nameSurnameLenght.Name = "nameSurnameLenght";
            this.nameSurnameLenght.Size = new System.Drawing.Size(139, 35);
            this.nameSurnameLenght.TabIndex = 6;
            this.nameSurnameLenght.Text = "Name Surname Lenght";
            this.nameSurnameLenght.UseVisualStyleBackColor = true;
            this.nameSurnameLenght.Click += new System.EventHandler(this.nameSurnameLenght_Click);
            // 
            // ageCourse
            // 
            this.ageCourse.Location = new System.Drawing.Point(13, 258);
            this.ageCourse.Name = "ageCourse";
            this.ageCourse.Size = new System.Drawing.Size(139, 35);
            this.ageCourse.TabIndex = 7;
            this.ageCourse.Text = "Age + Course ";
            this.ageCourse.UseVisualStyleBackColor = true;
            this.ageCourse.Click += new System.EventHandler(this.ageCourse_Click);
            // 
            // frmEmployeeGrid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1137, 409);
            this.Controls.Add(this.ageCourse);
            this.Controls.Add(this.nameSurnameLenght);
            this.Controls.Add(this.sameLetters);
            this.Controls.Add(this.age20to23);
            this.Controls.Add(this.surnameIorE);
            this.Controls.Add(this.nameCandJ);
            this.Controls.Add(this.btnOrderByName);
            this.Controls.Add(this.dgvEmployees);
            this.Name = "frmEmployeeGrid";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployees)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvEmployees;
        private System.Windows.Forms.Button btnOrderByName;
        private System.Windows.Forms.Button nameCandJ;
        private System.Windows.Forms.Button surnameIorE;
        private System.Windows.Forms.Button age20to23;
        private System.Windows.Forms.Button sameLetters;
        private System.Windows.Forms.Button nameSurnameLenght;
        private System.Windows.Forms.Button ageCourse;
    }
}

